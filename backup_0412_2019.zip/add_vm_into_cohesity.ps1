ForEach ($system in Get-Content �test.txt�) 
{ 
.\vm_addition.ps1 -JobId 2095147 -VmNames $system -Mode Append 
} 
